# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/usr/local/include;/usr/include".split(';') if "/usr/local/include;/usr/include" != "" else []
PROJECT_CATKIN_DEPENDS = "controller_interface;controller_manager;hardware_interface;pluginlib;roscpp;rospy;sensor_msgs;std_msgs".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-lminesweeper_base;/usr/lib/x86_64-linux-gnu/libboost_chrono.so;/usr/lib/x86_64-linux-gnu/libboost_system.so".split(';') if "-lminesweeper_base;/usr/lib/x86_64-linux-gnu/libboost_chrono.so;/usr/lib/x86_64-linux-gnu/libboost_system.so" != "" else []
PROJECT_NAME = "minesweeper_base"
PROJECT_SPACE_DIR = "/usr/local"
PROJECT_VERSION = "0.0.0"
